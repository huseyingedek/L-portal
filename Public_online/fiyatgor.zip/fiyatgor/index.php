<!DOCTYPE html>
<html lang="en">
    <head>

        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Lizay Pırlanta Barkod Sorgulama</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" type="text/css" />
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="stil.css" rel="stylesheet" />
    </head>
    <body>
	 <div id="wait"></div>
        <!-- Navigation-->

        <!-- Masthead-->
       
        <header class="masthead">
            
            <div class="container position-relative">
                
                <div class="row justify-content-center">
                    <div class="col-xl-6">
                        
                        <div class="text-center text-white">
                            <!-- Page heading-->
                             <img src="logo_s.png" witdh="200" height="200"/>
                            <h1 class="mb-5">Barkod Ara</h1>

                                <!-- Email address input-->
                                <div class="row">
                                    <div class="col-12">
                                        <input class="form-control form-control-lg" name="barkod_kodu" id="barkod_kodu" type="text" placeholder="Barkod Numarası" />

                                    </div>
                                    <div class="col"><br></br><button id="form_post" class="btn btn-primary btn-lg"  type="button">Barkod Sorgula</button></div>
                                    
                                </div>
                                
                                <!-- Submit success message-->
                                <!---->
                                <!-- This is what your users will see when the form-->
                                <!-- has successfully submitted-->

                                <!-- Submit error message-->
                                <!---->
                                <!-- This is what your users will see when there is-->
                                <!-- an error submitting the form-->

						<script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous"></script>


	 <style type="text/css">
        #wait {
          display: none;
          position: fixed;
          z-index: 1000;
          top: 0;
          left: 0;
          height: 100%;
          width: 100%;
          background: rgba(255, 255, 255, .8) url('http://i.stack.imgur.com/FhHRx.gif') 50% 50% no-repeat;
          opacity: 0.80;
          -ms-filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=80);
          filter: alpha(opacity=80)
        };
       
      </style>


                    </div>
                </div>
            </div>
        </header>
		<div class="card sonuc mt-6 -none">
							<h5 class="text-center mt-2">Sonuç </h5>
							<div class="sonuc_sonuc p4"></div>
                        </div>

        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>


		<script>

        $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
        });



        $('#barkod_kodu').on('keyup keypress keydown', function(e) {
           if (e.which ==13) {
             $( "#form_post" ).trigger( "click" );
           }
        });
        $('#form_post').on('click', function(e) {

          $.ajax({
            type: "POST",
            url: 'https://online.lizaypirlanta.com/fiyatgor/test.php',
            data: {
              _token: "{{ csrf_token() }}",
              barkod_kodu: $('#barkod_kodu').val(),
            },
            beforeSend: function() {
              $('#wait').css('display', 'block');
            },
            complete: function() {
              $('#wait').css('display', 'none');
            },
            success: function(data) {

               var veri = JSON.parse(data);
              $('.sonuc').removeClass('d-none');
              $('.sonuc_sonuc').html(' ');
              if (veri.data == null) {
                $('.sonuc_sonuc').html(`
							<div class="alert alert-danger p-3">Bu barkoda ait ürün bulunamadı.</div>
        					`);
              } else {
                var veri = JSON.parse(veri.data);
                $('.sonuc_sonuc').html(`

							<center>
								<div class="container container-fluid">
									<img class="radius" width="170" height="170" src="` + veri.ROW.IMGBASE64 + `">
										<h5 class="mt-3">` + veri.ROW.DETCOLOR + `</h5>
										<h5 class="text-center">` + veri.ROW.SPRICE + ` ` + veri.ROW.SPRICECURRENCY + `</h5>
										<p>Stok Durumu: ` + veri.ROW.ISWARE + `</p>
										<p>Model: ` + veri.ROW.MATERIAL + `</p>

								</center>
								<div class="table-responsive-lg">
								<table class="table">
									<thead>
										<tr>
											<th scope="col">Code</th>
											
											<th scope="col">Diamond (Ct)</th>
											<th scope="col">Color Stone</th>
											<th scope="col">Color / Clarity</th>
											<th scope="col">Gold K / Gr</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<th scope="row">` + veri.ROW.BATCHNUM + `</th>
											
											<td>` + veri.ROW.D1TEXT + `</td>
											<td>` + veri.ROW.COLORSTONE + `</td>
											<td>` + veri.ROW.COLORCLARITY + `</td>
											<td>` + veri.ROW.MATGRP + `</td>
										</tr>
									</tbody>

									</div>
									</div>
									
`);
              }
            },
            error: function(e){
                alert(e);
            }
          });
        })
      </script>
<style>

.radius{
	
	
	border-radius:30%;
}



</style>

    </body>
</html>
