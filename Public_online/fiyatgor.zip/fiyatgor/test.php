<?php
		require_once 'nusoap.php';
		require_once 'caniasConnector.php';


		$barkod_kodu =  trim(strtoupper($_POST['barkod_kodu']));
   	    $caniasConnector = new  caniasConnector();
        $caniasConnector->wsCanias("CertificateCHECK", [$barkod_kodu]);
        $sonuc = $caniasConnector->wsGetResponse();
        $sonuc_json = json_decode($sonuc, true);


        if (!empty($sonuc_json)) {
            foreach($sonuc_json["ROW"] as $key=>$value)
          {
            if ($key == "ISPICT") {
              $image = str_replace(array('-----BEGIN CERTIFICATE-----', '-----END CERTIFICATE-----'), '', $value);
              $image = "data:image/png;base64,".$image;
              $sonuc_json["ROW"]["IMGBASE64"] = $image;
            }



          $color_stone = '';
          if (is_array($sonuc_json['ROW']['D3TEXT']))
          {
            $color_stone_array = $sonuc_json['ROW']['D3TEXT'];
            foreach ($color_stone_array as $data)
            {
              $color_stone .= ' '.$data;
            }
          }
          else
          {
            $color_stone = $sonuc_json['ROW']['D3TEXT'];
          }
          $color_clarity_1 = trim(mb_substr($sonuc_json["ROW"]['D1TEXT'], 8, (strlen($sonuc_json["ROW"]['D1TEXT']) - 1), 'UTF-8'));
          if ($color_clarity_1 != '')
          {
            $color_clarity_1 = "D1:".$color_clarity_1;
          }

          $sonuc_json["ROW"]['COLORSTONE'] = $color_stone;
          $sonuc_json["ROW"]['COLORCLARITY'] = $color_clarity_1;
          }



        // RETAIL BATCH CHECK SERVİSİ
        $caniasConnector->wsCanias("RetailBatchCheck", ['P2000C', $barkod_kodu]);
        $sonucs = $caniasConnector->wsGetResponse();
        $sonuc_jsons = json_decode($sonucs, true);


        foreach($sonuc_jsons as $key=>$value)
        {
           if ($value["BARKOD"] == $barkod_kodu) {
              $sonuc_json["ROW"]["LASTPRICE"] = $value["LASTPRICE"];
              $sonuc_json["ROW"]["COSTCURRENCY"] = $value["COSTCURRENCY"];
              $sonuc_json["ROW"]["ISWARE"] = $value["ISWARE"];
              $sonuc_json["ROW"]["ISSTCK"] = $value["ISSTCK"];
              $sonuc_json["ROW"]["DETCOLOR"] = $value["DETCOLOR"];
              $sonuc_json["ROW"]["SPRICE"] = $value["SPRICE"];
              $sonuc_json["ROW"]["SPRICECURRENCY"] = $value["SPRICECURRENCY"];
           }
        }


       echo json_encode([
          "status"=>"true",
          "data"=>json_encode($sonuc_json)

        ]);

        }else{
          echo json_encode( [
            "status"=>"false",
            "data"=>null
          ]);
        }





?>
